package com.blitzmobileapp.imagepicker;



import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.telecom.Call;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.esafirm.imagepicker.features.ImagePicker;
import com.esafirm.imagepicker.model.Image;
import com.facebook.react.ReactActivity;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.yalantis.ucrop.UCrop;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;


public class ImagePickerModule extends ReactContextBaseJavaModule {
  private ReactApplicationContext reactContext;
  public static ImagePicker imagePicker;
  public Fragment cf;
  ArrayList<String> returnValue = new ArrayList<>();
  public static MainActivity mainActivity;
  FragmentManager manager;
  private static final int PICK_FROM_GALLERY = 2;

  ImagePickerModule(ReactApplicationContext context) {
    super(context);
    reactContext = context;

  }

  @NonNull
  @Override
  public String getName() {
    return "imagePicker";
  }

  @ReactMethod
  public void getImage(Callback callback) {
    callback.invoke(MainActivity.imageUri.toString());
  }
  private String encodeImage(Bitmap bm)
  {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    bm.compress(Bitmap.CompressFormat.JPEG,100,baos);
    byte[] b = baos.toByteArray();
    String encImage = Base64.encodeToString(b, Base64.DEFAULT);
    return encImage;
  }
  @ReactMethod
  public void openImagePicker(Callback callback) {
    MainActivity.imageUri = null;

    ImagePicker.create(getCurrentActivity())
            .single()
            .start();
    if (MainActivity.imageUri != null) {
      try {
        final InputStream imageStream = getCurrentActivity().getContentResolver().openInputStream(MainActivity.imageUri);
        final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
        String encodedImage = encodeImage(selectedImage);
        JSONObject image = new JSONObject();
        image.put("uri",MainActivity.imageUri.toString());
        image.put("data",encodedImage);
        callback.invoke(image.toString());
        MainActivity.imageUri = null;
      } catch (FileNotFoundException e) {
        e.printStackTrace();
      } catch (JSONException e) {
        e.printStackTrace();
      }
    }
  }
}

